#!/usr/bin/env bash

	if [ "$UID" -ne "0" ]
		then
			echo "YOU AREN'T ROOT!"
			exit 1
	fi

list=`sudo find / -type f -name "list_fordns" 2> /dev/null | head -1`
arq=`sudo find / -type f -name "fordns" 2> /dev/null | head -1`

	if [ -e /etc/bashrc ]
		then
			bashrc="/etc/bashrc"
		else
			bashrc="/etc/bash.bashrc"
	fi

	reset
	echo "File located in: $arq"
	sleep 2
	echo "Copying fordns to /usr/local/bin/"
	sleep 2
	cp -f $arq /usr/local/bin/ 2> /dev/null
		if [ "$?" -gt "0" ]
		then
			echo "An error has ocurred."
			exit 1
		fi
	echo "Setting permissions"
	sleep 2
	chmod a+rx /usr/local/bin/fordns

	echo "List located in: $list"
	sleep 2
	echo "Copying list_fordns to /usr/local/bin/"
	sleep 2
	cp -f $list /usr/local/bin/ 2> /dev/null
	if [ "$?" -gt "0" ]
	then
                        echo "An error has ocurred."
                        exit 1
                fi
	echo "Setting permissions"
	sleep 2
	chmod a+rwx /usr/local/bin/list_fordns

	echo 'alias fordns="fordns | tee $HOME/log"' >> $bashrc
	source $bashrc
	echo "DONE!"
exit 0


